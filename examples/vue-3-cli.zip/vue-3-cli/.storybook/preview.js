export const parameters = {
  docs: {
    iframeHeight: '60px',
  },
};
